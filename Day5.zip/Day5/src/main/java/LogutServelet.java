

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LogutServelet
 */
@WebServlet("/LogutServelet")
public class LogutServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogutServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Cookie ck=new Cookie("email",null);
		pw.print(ck);
		ck.setMaxAge(0);
		response.addCookie(ck);
		
		pw.print("<html>\r\n"
				+ "<head>\r\n"
				+ "<meta charset=\"ISO-8859-1\">\r\n"
				+ "<title>Thank You</title>\r\n"
				+ "<style>\r\n"
				+ "img {\r\n"
				+ "  display: block;\r\n"
				+ "  margin-left: auto;\r\n"
				+ "  margin-right: auto;\r\n"
				+ "  width: 50%;\r\n"
				+ "}\r\n"
				+ "</style>\r\n"
				+ "</head>\r\n"
				+ "<body>\r\n"
				+ "<div style=\"clear: both\">\r\n"
				+ "<h1 style = \"display:inline;\"> Thank You !!!   </h1>\r\n"
				+ "<h3 style = \"display:inline;\">Visit Again...</h3>\r\n"
				+ "</div>\r\n"
				+ "<br>\r\n"
				+ "<h3>Click <a href = \"page2.html\">here</a> to go back to login Page</h3><br>\r\n"
				+ "<img src = \"tanq.jpg\" alt = \"Thank You Image Here...\" >\r\n"
				+ "\r\n"
				+ "</body>\r\n"
				+ "</html>");
		pw.close();
	}

	

}
