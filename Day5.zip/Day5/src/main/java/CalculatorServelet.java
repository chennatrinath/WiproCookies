

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalculatorServelet
 */
@WebServlet("/CalculatorServelet")
public class CalculatorServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalculatorServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Cookie ck[] = request.getCookies();
		String name = null;
		if(ck!=null) {
		name = ck[0].getValue();
		PrintWriter pw = response.getWriter();
		if(!name.equals("")||name!=null){
			
			
			int num1 = Integer.parseInt(request.getParameter("number1"));
			int num2 = Integer.parseInt(request.getParameter("number2"));
			 
			response.setContentType("text/html");
			
			
			pw.print("<html><body><h1> Welcome "+ name +"</h1></body></html>");
			
			if(request.getParameter("operator").equals("sum")) {
				int sum = num1+num2;
				pw.print("<html><head><title>Results</title> <style>h2{color:megenta}</style></head><Body> <h3>The Sum of "+num1+" and "+num2+" is "+sum+" </h3><br> <h4>Click <a href = LogutServelet>here</a> to exit</h4></body></html> ");			
			}else if(request.getParameter("operator").equals("diff")) {
				int diff = num1-num2;
				pw.print("<html><head><title>Results</title> <style>h2{color:megenta}</style></head><Body> <h3>The Difference of "+num1+" and "+num2+" is "+diff+" </h3><br> <h4>Click <a href = LogutServelet>here</a> to exit</h4></body></html> ");
			}else if(request.getParameter("operator").equals("mul")) {
				int mul = num1*num2;
				pw.print("<html><head><title>Results</title> <style>h2{color:megenta}</style></head><Body> <h3>The multiplication of "+num1+" and "+num2+" is "+mul+" </h3><br> <h4>Click <a href = LogutServelet>here</a> to exit</h4></body></html> ");
			}else if(request.getParameter("operator").equals("div")) {
				int div = num1/num2;
				pw.print("<html><head><title>Results</title> <style>h2{color:megenta}</style></head><Body> <h3>The division of "+num1+" and "+num2+" is "+div+" </h3><br> <h4>Click <a href = LogutServelet>here</a> to exit</h4></body></html> ");
			}else if(request.getParameter("operator").equals("mod")) {
				int mod = num1%num2;
				pw.print("<html><head><title>Results</title> <style>h2{color:megenta}</style></head><Body> <h3>The Modulo division of "+num1+" and "+num2+" is "+mod+" </h3><br> <h4>Click <a href = LogutServelet>here</a> to exit</h4></body></html> ");
			}else {
				pw.print("No Operation is Performeed");
			}
		}
		}else {
			PrintWriter pw = response.getWriter();
			RequestDispatcher rd = request.getRequestDispatcher("page2.html");
			pw.print("Invalid Credentials...");
			rd.include(request, response);
		}
		

	}

}
